package de.spigot.free.forty.chestsave.util;

import java.io.File;
import java.io.IOException;

import org.bukkit.Location;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

public class Config {

	public static File chestfile = new File("plugins//ChestSave//Chest.yml");
	public static File configfile = new File("plugins//ChestSave//Config.yml");
	public static FileConfiguration chestcfg = YamlConfiguration.loadConfiguration(chestfile);
	public static FileConfiguration configcfg = YamlConfiguration.loadConfiguration(configfile);

	public static void save() {
		try {
			chestcfg.save(chestfile);
			configcfg.save(configfile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void loadAndCreate() {
		if (configfile.exists()) {
			try {
				configcfg.load(configfile);
				chestcfg.load(chestfile);
			} catch (IOException | InvalidConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			try {
				configfile.createNewFile();
				chestfile.createNewFile();
				configcfg.set("Maxchest", 1);
				save();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public static void createChest(Player player, Location loc, int id) {
		int X = loc.getBlockX();
		int Y = loc.getBlockY();
		int Z = loc.getBlockZ();
		String World = loc.getWorld().getName();
		String setter = X + "-" + Y + "-" + Z + "-" + World;
		chestcfg.set("User." + player.getUniqueId().toString() + ".Locs." + id, setter);
		chestcfg.set("User." + player.getUniqueId().toString() + ".ID", id);
		chestcfg.set("Locs." + setter, player.getUniqueId().toString());
		save();
	}

	public static void createPlayer(Player player) {
		if (chestcfg.getString("User." + player.getUniqueId().toString() + ".ID") == null) {
			chestcfg.set("User." + player.getUniqueId().toString() + ".ID", 0);
			save();
		}
	}

	public static int getID(Player player) {
		return chestcfg.getInt("User." + player.getUniqueId().toString() + ".ID");
	}

	public static String getName(Location loc) {
		int X = loc.getBlockX();
		int Y = loc.getBlockY();
		int Z = loc.getBlockZ();
		String World = loc.getWorld().getName();
		String setter = X + "-" + Y + "-" + Z + "-" + World;
		return chestcfg.getString("Locs." + setter);
	}
	
	public static void deleteChest(Player player, Location loc, int ID, int oldID) {
		int X = loc.getBlockX();
		int Y = loc.getBlockY();
		int Z = loc.getBlockZ();
		String World = loc.getWorld().getName();
		String setter = X + "-" + Y + "-" + Z + "-" + World;
		chestcfg.set("User." + player.getUniqueId().toString() + ".ID", ID);
		chestcfg.set("User." + player.getUniqueId().toString() + ".Locs." + oldID, null);
		chestcfg.set("Locs." + setter, null);
		save();
	}

//Config

	public static int getMaxChests() {
		return configcfg.getInt("Maxchest");
	}
	
	//UUID & Name
	public static void managePlayer(String uuid, Player player) {
		if (chestcfg.getString("UUIDName.uuid."+ uuid) == null) {
			chestcfg.set("UUIDName.uuid."+ uuid, player.getName());
			chestcfg.set("UUIDName.name."+ player.getName(), uuid);
			save();
		} else {
			String Name = chestcfg.getString("UUIDName.uuid."+ uuid);
			if(player.getName() != Name) {
				chestcfg.set("UUIDName.uuid."+ uuid, player.getName());
				save();
			}
			save();
		}
	}
	
	public static String getUUIDByName(Player player) {
		return chestcfg.getString("UUIDName.name." + player.getName());
	}
	
	public static String getNameByUUID(String uuid) {
		return chestcfg.getString("UUIDName.uuid." + uuid);
	}
}	