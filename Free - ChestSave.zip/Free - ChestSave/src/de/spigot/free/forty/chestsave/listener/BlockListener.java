package de.spigot.free.forty.chestsave.listener;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerInteractEvent;

import de.spigot.free.forty.chestsave.ChestSave;
import de.spigot.free.forty.chestsave.util.Config;

public class BlockListener implements Listener {

	@EventHandler
	public void clickBlock(PlayerInteractEvent event) {
		Player player = event.getPlayer();
		if (event.getClickedBlock().getType() == Material.CHEST) {
			Location loc = event.getClickedBlock().getLocation();
			int ID = Config.getID(player);
			if (!ChestSave.Savers.contains(player)) {
				if (Config.getNameByUUID(Config.getName(loc)).equals(player.getName())) {
					event.setCancelled(false);
				} else {
					if (!player.hasPermission("Admin")) {
						player.sendMessage(ChestSave.Prefix + "�cDie Kiste ist auf �e"
								+ Config.getNameByUUID(Config.getName(loc)) + " �cgesichert!");
						event.setCancelled(true);
						return;
					}
				}
			} else {
				if (Config.getName(loc) == null) {
					if (ID >= Config.getMaxChests()) {
						player.sendMessage(ChestSave.Prefix + "�cDu kannst maximal �c" + Config.getMaxChests()
								+ " �cKisten sichern!");
						event.setCancelled(true);
						return;
					}
					ChestSave.Savers.remove(player);
					ID++;
					Config.createChest(player, loc, ID);
					player.sendMessage(ChestSave.Prefix + "�7Du hast die Kiste erfolgreich gesichert!");
					event.setCancelled(true);
				} else {
					if (Config.getName(loc).equals(player.getUniqueId().toString())) {
						int theid = Config.getID(player);
						int newID;
						if (theid == 1) {
							newID = 0;
						} else {
							newID = theid - 1;
						}

						Config.deleteChest(player, loc, newID, theid);
						player.sendMessage(ChestSave.Prefix + "�7Du hast die Kiste entsichert!");
						ChestSave.Savers.remove(player);
						event.setCancelled(true);
						return;
					} else {
						player.sendMessage(
								ChestSave.Prefix + "�cDie Kiste ist auf �e" + Config.getNameByUUID(Config.getName(loc)) + " �cgesichert!!");
						event.setCancelled(true);
					}
				}
			}

		}
	}

	@EventHandler
	public void onBreak(BlockBreakEvent event) {
		Player player = event.getPlayer();
		Location loc = event.getBlock().getLocation();
		if (Config.getNameByUUID(Config.getName(loc)).equals(player.getName())) {
			event.setCancelled(false);
		} else {
			if (!player.hasPermission("Admin")) {
				player.sendMessage(ChestSave.Prefix + "�cDie Kiste ist auf �e"
						+ Config.getNameByUUID(Config.getName(loc)) + " �cgesichert!");
				event.setCancelled(true);
				return;
			}
		}
	}

}
