package de.spigot.free.forty.chestsave.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import de.spigot.free.forty.chestsave.ChestSave;
import de.spigot.free.forty.chestsave.util.Config;

public class CSaveCommand implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command command, String arg2, String[] args) {
		Player player = (Player) sender;
		if (args.length != 0) {
			player.sendMessage(ChestSave.Prefix + "�cBenutze �7/csave �c!");
			return true;
		}
		
		if(ChestSave.Savers.contains(player)) {
			ChestSave.Savers.remove(player);
			player.sendMessage(ChestSave.Prefix + "�7Du kannst nun keine Kiste mehr sichern lassen!");
		} else {
			ChestSave.Savers.add(player);
			player.sendMessage(ChestSave.Prefix + "�7Du hast nun �c10 Sekunden �7Zeit eine Kiste anzuklicken!");
			new BukkitRunnable() {
				
				@Override
				public void run() {
					if(ChestSave.Savers.contains(player)) {
						ChestSave.Savers.remove(player);
						player.sendMessage(ChestSave.Prefix + "�7Du kannst nun keine Kiste mehr sichern lassen!");
					}
					cancel();
				}
			}.runTaskLater(ChestSave.getPlugin(ChestSave.class), 10*20);
		}
			return false;
	}

}
