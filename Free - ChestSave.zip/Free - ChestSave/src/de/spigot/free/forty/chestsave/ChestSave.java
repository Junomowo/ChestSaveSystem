package de.spigot.free.forty.chestsave;

import java.util.ArrayList;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import de.spigot.free.forty.chestsave.command.CSaveCommand;
import de.spigot.free.forty.chestsave.listener.BlockListener;
import de.spigot.free.forty.chestsave.listener.JoinListener;
import de.spigot.free.forty.chestsave.util.Config;

public class ChestSave extends JavaPlugin{

	public static String Prefix = "�6ChestSave �8| ";
	public static ArrayList<Player> Savers  = new ArrayList<Player>();
	
	@Override
	public void onEnable() {
		Config.loadAndCreate();
		Bukkit.getPluginManager().registerEvents(new BlockListener(), this);
		Bukkit.getPluginManager().registerEvents(new JoinListener(), this);
		getCommand("csave").setExecutor(new CSaveCommand());
	}
	
}
