package de.spigot.free.forty.chestsave.listener;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import de.spigot.free.forty.chestsave.util.Config;

public class JoinListener implements Listener{
	
	@EventHandler
	public void onJoin(PlayerJoinEvent event) {
		Player player = event.getPlayer();
		Config.managePlayer(player.getUniqueId().toString(), player);
		Config.createPlayer(player);
	}

}
